const state = {
  products: [],
  favorites: JSON.parse(localStorage.getItem("shopee-favorites") || "[]"),
  mode: "not_configured"
};

const $ = s => document.querySelector(s);
const money = n => Number(n || 0).toLocaleString("pt-BR",{style:"currency",currency:"BRL"});
const toast = msg => { const t=$("#toast"); t.textContent=msg; t.classList.add("show"); setTimeout(()=>t.classList.remove("show"),2800); };

async function api(url, options) {
  const r = await fetch(url, options);
  const data = await r.json().catch(()=>({ok:false,message:"Resposta inválida do servidor."}));
  if (!r.ok || data.ok === false) throw new Error(data.message || "Erro inesperado.");
  return data;
}

function isFav(p){ return state.favorites.some(x=>String(x.itemId)===String(p.itemId)); }
function saveFav(){ localStorage.setItem("shopee-favorites", JSON.stringify(state.favorites)); }

function productCard(p) {
  const image = p.imageUrl || "";
  return `<article class="card" data-shop="${p.shopId}" data-item="${p.itemId}">
    <div class="thumb">
      <img src="${escapeHtml(image)}" alt="" onerror="this.style.visibility='hidden'">
      <button class="fav ${isFav(p)?"on":""}" data-fav="${p.itemId}" title="Favoritar">${isFav(p)?"★":"☆"}</button>
      <span class="score">${p.opportunity}/100</span>
    </div>
    <div class="card-body">
      <div class="card-title">${escapeHtml(p.productName || "Produto")}</div>
      <div class="price">${money(p.priceMin)}</div>
      <div class="meta"><span>★ ${Number(p.rating||p.ratingStar||0).toFixed(1)}</span><span>${Number(p.sales||0).toLocaleString("pt-BR")} vendas</span></div>
      <div class="meta"><span>${Number(p.discountRate||0)}% OFF</span><span class="commission">${Number(p.commissionRate||0).toFixed(1)}% comissão</span></div>
    </div>
  </article>`;
}

function escapeHtml(s){return String(s??"").replace(/[&<>"']/g,m=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#039;"}[m]));}

async function loadStatus(){
  try{
    const d=await api("/api/status");
    state.mode=d.mode;
    $("#modeBadge").textContent=d.configured?"● SHOPEE API CONECTADA":"● CONFIGURAÇÃO PENDENTE";
    $("#modeBadge").style.color=d.configured?"#65d69a":"#f4a261";
    $("#status").textContent=d.configured?"Shopee API configurada":"Configure o .env";
  }catch(e){$("#status").textContent="Servidor indisponível";}
}

async function loadProducts(){
  const q=$("#search").value.trim();
  let sort=Number($("#sort").value);
  if(sort===6){
    sort=2;
  }
  $("#products").innerHTML="<div class='notice'>Buscando produtos...</div>";
  try{
    const d=await api(`/api/products?q=${encodeURIComponent(q)}&sort=${sort}&limit=24`);
    let items=d.items||[];
    if(Number($("#sort").value)===6) items.sort((a,b)=>b.opportunity-a.opportunity);
    state.products=items;
    $("#resultsTitle").textContent=q?`Resultados para “${q}”`:"Produtos";
    $("#resultsInfo").textContent=`${items.length} produtos encontrados · ${"dados reais da Shopee"}`;
    $("#products").innerHTML=items.length?items.map(productCard).join(""):"<div class='notice'>Nenhum produto encontrado.</div>";
    bindCards($("#products"));
  }catch(e){
    $("#products").innerHTML=`<div class="notice">${escapeHtml(e.message)}</div>`;
  }
}

function bindCards(root){
  root.querySelectorAll(".card").forEach(c=>c.addEventListener("click",e=>{
    if(e.target.closest(".fav")) return;
    const p=state.products.find(x=>String(x.itemId)===c.dataset.item);
    if(p) openProduct(p);
  }));
  root.querySelectorAll("[data-fav]").forEach(b=>b.addEventListener("click",e=>{
    e.stopPropagation();
    const p=state.products.find(x=>String(x.itemId)===b.dataset.fav);
    if(p) toggleFavorite(p);
  }));
}

function toggleFavorite(p){
  if(isFav(p)) state.favorites=state.favorites.filter(x=>String(x.itemId)!==String(p.itemId));
  else state.favorites=[p,...state.favorites];
  saveFav();
  renderFavorites();
  toast(isFav(p)?"Adicionado aos favoritos":"Removido dos favoritos");
  document.querySelectorAll(`[data-fav="${p.itemId}"]`).forEach(b=>{b.textContent=isFav(p)?"★":"☆";b.classList.toggle("on",isFav(p));});
}

function renderFavorites(){
  const el=$("#favorites");
  if(!state.favorites.length){el.innerHTML="<div class='notice'>Você ainda não favoritou nenhum produto.</div>";return;}
  el.innerHTML=state.favorites.map(productCard).join("");
  bindCards(el);
}

function openProduct(p){
  const reasons=(p.opportunityReasons||[]).map(r=>`<div class="reason"><div class="meta"><span>${r.label}</span><b>${r.value}/${r.max}</b></div><div class="bar"><i style="width:${(r.value/r.max)*100}%"></i></div></div>`).join("");
  $("#modalContent").innerHTML=`<div class="detail">
    <img class="detail-img" src="${escapeHtml(p.imageUrl||"https://placehold.co/600x600?text=Shopee")}" alt="">
    <div>
      <div class="eyebrow">OPORTUNIDADE ${p.opportunity}/100</div>
      <h2>${escapeHtml(p.productName)}</h2>
      <div class="detail-price">${money(p.priceMin)}${p.priceMax&&p.priceMax!==p.priceMin?` <small style="font-size:13px;color:#858b96">até ${money(p.priceMax)}</small>`:""}</div>
      <div class="chips"><span class="chip">${Number(p.discountRate||0)}% OFF</span><span class="chip">★ ${Number(p.rating||0).toFixed(1)}</span><span class="chip">${Number(p.sales||0).toLocaleString("pt-BR")} vendas</span><span class="chip">${Number(p.commissionRate||0).toFixed(1)}% comissão</span></div>
      <div class="notice">A pontuação é uma heurística de priorização baseada somente nos dados retornados pela Shopee; não é garantia de vendas.</div>
      ${reasons}
      <div class="actions">
        <button class="buy" id="buyBtn">COMPRAR NA SHOPEE</button>
        <button id="linkBtn">COPIAR LINK DE AFILIADO</button>
        <button id="favModal">${isFav(p)?"★ Favoritado":"☆ Favoritar"}</button>
      </div>
      <div id="linkNotice"></div>
    </div>
  </div>`;
  $("#modal").classList.remove("hidden");
  $("#closeModal").onclick=()=>$("#modal").classList.add("hidden");
  $("#favModal").onclick=()=>{toggleFavorite(p);$("#favModal").textContent=isFav(p)?"★ Favoritado":"☆ Favoritar";};
  $("#linkBtn").onclick=()=>generateLink(p);
  $("#buyBtn").onclick=async()=>{
    const url=p.offerLink||p.productLink;
    if(!url){toast("A Shopee não forneceu uma URL para este produto.");return;}
    if(p.offerLink){ window.open(p.offerLink,"_blank","noopener"); return; }
    try{
      const d=await api("/api/affiliate-link",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({originUrl:url})});
      window.open(d.link,"_blank","noopener");
    }catch(e){toast(e.message);}
  };
}

async function generateLink(p){
  const notice=$("#linkNotice");
  notice.innerHTML="<div class='notice'>Gerando link oficial...</div>";
  try{
    const d=await api("/api/affiliate-link",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({originUrl:p.productLink})});
    await navigator.clipboard.writeText(d.link);
    notice.innerHTML="<div class='notice'>Link de afiliado copiado.</div>";
    toast("Link de afiliado copiado!");
  }catch(e){notice.innerHTML=`<div class='notice'>${escapeHtml(e.message)}</div>`;}
}

function showView(name){
  document.querySelectorAll(".view").forEach(v=>v.classList.add("hidden"));
  $(`#${name}View`).classList.remove("hidden");
  document.querySelectorAll(".nav").forEach(n=>n.classList.toggle("active",n.dataset.view===name));
  $("#pageTitle").textContent=name==="dashboard"?"Encontre oportunidades":name==="products"?"Produtos": "Favoritos";
  if(name==="favorites") renderFavorites();
}

async function initDashboard(){
  try{
    const d=await api("/api/products?sort=6&limit=24");
    state.products=d.items||[];
    const items=[...state.products].sort((a,b)=>b.opportunity-a.opportunity);
    $("#stats").innerHTML=[
      ["Produtos encontrados",items.length],["Melhor oportunidade",items[0]?items[0].opportunity+"/100":"—"],
      ["Maior comissão",items.length?Math.max(...items.map(x=>x.commissionRate||0)).toFixed(1)+"%":"—"],
      ["Mais vendido",items.length?Math.max(...items.map(x=>x.sales||0)).toLocaleString("pt-BR")+"":"—"]
    ].map(x=>`<div class="stat"><small>${x[0]}</small><b>${x[1]}</b></div>`).join("");
    $("#topProducts").innerHTML=items.slice(0,8).map(productCard).join("");
    bindCards($("#topProducts"));
  }catch(e){$("#topProducts").innerHTML=`<div class="notice">${escapeHtml(e.message)}</div>`;}
}

$("#heroSearch").onclick=()=>{showView("products");loadProducts();};
$("#seeAll").onclick=()=>{showView("products");loadProducts();};
$("#searchBtn").onclick=loadProducts;
$("#search").addEventListener("keydown",e=>{if(e.key==="Enter")loadProducts();});
$("#sort").onchange=loadProducts;
document.querySelectorAll(".nav").forEach(n=>n.onclick=()=>{showView(n.dataset.view);if(n.dataset.view==="products")loadProducts();});
$("#closeModal").onclick=()=>$("#modal").classList.add("hidden");
$("#modal").addEventListener("click",e=>{if(e.target.id==="modal")$("#modal").classList.add("hidden");});
$("#testApi").onclick=async()=>{
  try{const d=await api("/api/test");toast(d.message);}
  catch(e){toast(e.message);}
};

(async()=>{await loadStatus();await initDashboard();})();
