const crypto = require("crypto");

const ENDPOINT = "https://open-api.affiliate.shopee.com.br/graphql";

function config() {
  return {
    appId: String(process.env.SHOPEE_APP_ID || "").trim(),
    secret: String(process.env.SHOPEE_SECRET || "").trim(),
    subIds: String(process.env.SHOPEE_SUB_IDS || "")
      .split(",").map(s => s.trim()).filter(Boolean).slice(0, 5)
  };
}

function configStatus() {
  const c = config();
  return {
    configured: Boolean(c.appId && c.secret),
    hasAppId: Boolean(c.appId),
    hasSecret: Boolean(c.secret),
    endpoint: ENDPOINT
  };
}

function makeHeaders(payload, appId, secret) {
  const timestamp = Math.floor(Date.now() / 1000).toString();
  const signature = crypto.createHash("sha256")
    .update(`${appId}${timestamp}${payload}${secret}`, "utf8")
    .digest("hex");

  return {
    "Content-Type": "application/json",
    "Accept": "application/json",
    "User-Agent": "Shopee-Oportunidades/1.0",
    "Authorization": `SHA256 Credential=${appId}, Timestamp=${timestamp}, Signature=${signature}`
  };
}

function friendlyShopeeError(body, status) {
  const error = Array.isArray(body?.errors) ? body.errors[0] : null;
  const code = error?.extensions?.code;
  const message = error?.message || body?.message || `HTTP ${status}`;

  const map = {
    10020: "Credencial inválida. Confira o AppId da Open API e o Secret exatamente como foram fornecidos pela Shopee.",
    10021: "Assinatura inválida. O AppId/Secret informado não corresponde à assinatura esperada pela Shopee.",
    10030: "A Shopee recusou a requisição por limite de chamadas. Aguarde e tente novamente.",
    10031: "Acesso negado para esta operação. Verifique se sua conta tem acesso à Open API.",
    10035: "Sua conta não possui acesso à Shopee Open API ou a operação não está habilitada.",
    11001: "Os parâmetros enviados para a consulta são inválidos."
  };

  return {
    code,
    message: map[code] ? `${map[code]} (Shopee ${code})` : `${message}${code ? ` (Shopee ${code})` : ""}`
  };
}

async function request(query, variables = {}) {
  const c = config();
  if (!c.appId || !c.secret) {
    const err = new Error("SHOPEE_APP_ID e SHOPEE_SECRET são obrigatórios no .env.");
    err.kind = "CONFIG";
    throw err;
  }

  // A assinatura precisa usar exatamente o JSON enviado no corpo.
  const payload = JSON.stringify({ query, variables });
  const headers = makeHeaders(payload, c.appId, c.secret);

  let response;
  try {
    response = await fetch(ENDPOINT, { method: "POST", headers, body: payload });
  } catch (cause) {
    const err = new Error("Não foi possível conectar à Shopee. Verifique sua internet, firewall ou antivírus e tente novamente.");
    err.kind = "NETWORK";
    err.cause = cause;
    throw err;
  }

  let body;
  try {
    body = await response.json();
  } catch {
    const err = new Error(`A Shopee respondeu com conteúdo inválido (HTTP ${response.status}).`);
    err.kind = "API";
    throw err;
  }

  if (!response.ok || body?.errors?.length) {
    const info = friendlyShopeeError(body, response.status);
    const err = new Error(info.message);
    err.kind = "SHOPEE";
    err.code = info.code;
    err.raw = body;
    throw err;
  }

  return body.data;
}

const PRODUCT_FIELDS = `
  itemId
  commissionRate
  sellerCommissionRate
  shopeeCommissionRate
  commission
  sales
  priceMax
  priceMin
  productCatIds
  ratingStar
  priceDiscountRate
  imageUrl
  productName
  shopId
  shopName
  shopType
  productLink
  offerLink
  periodStartTime
  periodEndTime
`;

function percent(value) {
  const n = Number(value || 0);
  return n <= 1 ? n * 100 : n;
}

function normalizeProduct(p) {
  const priceMin = Number(p.priceMin || 0);
  const priceMax = Number(p.priceMax || 0);
  const discountRate = Number(p.priceDiscountRate || 0);
  const commissionRate = percent(p.commissionRate);
  const sellerCommissionRate = percent(p.sellerCommissionRate);
  const shopeeCommissionRate = percent(p.shopeeCommissionRate);
  const rating = Number(p.ratingStar || 0);
  const sales = Number(p.sales || 0);

  const demand = Math.min(1, Math.log10(sales + 1) / 5);
  const payout = Math.min(1, commissionRate / 25);
  const quality = Math.min(1, rating / 5);
  const deal = Math.min(1, discountRate / 50);
  const opportunity = Math.round(100 * (0.40 * demand + 0.30 * payout + 0.20 * quality + 0.10 * deal));

  const originalPrice = discountRate > 0 && priceMin > 0
    ? priceMin / (1 - Math.min(discountRate, 99) / 100)
    : null;

  return {
    ...p,
    priceMin,
    priceMax,
    originalPrice,
    discountRate,
    commissionRate,
    sellerCommissionRate,
    shopeeCommissionRate,
    commissionValue: Number(p.commission || 0),
    rating,
    sales,
    categoryIds: Array.isArray(p.productCatIds) ? p.productCatIds.filter(Boolean) : [],
    opportunity,
    opportunityReasons: [
      { label: "Vendas", value: Math.round(demand * 40), max: 40 },
      { label: "Comissão", value: Math.round(payout * 30), max: 30 },
      { label: "Avaliação", value: Math.round(quality * 20), max: 20 },
      { label: "Desconto", value: Math.round(deal * 10), max: 10 }
    ]
  };
}

async function searchProducts({ keyword = "", sortType = 1, page = 1, limit = 24 } = {}) {
  const query = `query ProductOffers($keyword: String, $sortType: Int, $page: Int, $limit: Int) {
    productOfferV2(keyword: $keyword, listType: 0, sortType: $sortType, page: $page, limit: $limit) {
      nodes { ${PRODUCT_FIELDS} }
      pageInfo { page limit hasNextPage }
    }
  }`;

  const data = await request(query, {
    keyword: keyword || null,
    sortType: Number(sortType) || 1,
    page: Math.max(1, Number(page) || 1),
    limit: Math.min(50, Math.max(1, Number(limit) || 24))
  });

  const result = data?.productOfferV2;
  return {
    items: (result?.nodes || []).map(normalizeProduct),
    pageInfo: result?.pageInfo || { page, limit, hasNextPage: false }
  };
}

async function getProduct(shopId, itemId) {
  const query = `query ProductOffer($shopId: Int64, $itemId: Int64) {
    productOfferV2(shopId: $shopId, itemId: $itemId, page: 1, limit: 1) {
      nodes { ${PRODUCT_FIELDS} }
      pageInfo { page limit hasNextPage }
    }
  }`;

  const data = await request(query, { shopId: Number(shopId), itemId: Number(itemId) });
  const item = data?.productOfferV2?.nodes?.[0];
  return item ? normalizeProduct(item) : null;
}

function validateShopeeUrl(originUrl) {
  try {
    const url = new URL(String(originUrl || "").trim());
    const host = url.hostname.toLowerCase();
    return url.protocol === "https:" && (host === "shopee.com.br" || host.endsWith(".shopee.com.br"));
  } catch {
    return false;
  }
}

async function generateAffiliateLink(originUrl, subIds = []) {
  const clean = String(originUrl || "").trim();
  if (!validateShopeeUrl(clean)) {
    const err = new Error("A URL precisa ser uma URL HTTPS válida da Shopee Brasil e deve apontar para o produto que você selecionou.");
    err.kind = "VALIDATION";
    throw err;
  }

  const c = config();
  const ids = (subIds.length ? subIds : c.subIds).slice(0, 5);
  const query = `mutation GenerateShortLink($input: GenerateShortLinkInput!) {
    generateShortLink(input: $input) { shortLink }
  }`;

  const data = await request(query, {
    input: { originUrl: clean, subIds: ids }
  });

  const link = data?.generateShortLink?.shortLink;
  if (!link) {
    const err = new Error("A Shopee não retornou o link de afiliado para este produto.");
    err.kind = "LINK";
    throw err;
  }
  return link;
}

module.exports = { ENDPOINT, configStatus, searchProducts, getProduct, generateAffiliateLink };
