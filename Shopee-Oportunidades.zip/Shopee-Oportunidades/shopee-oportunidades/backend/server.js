require("dotenv").config();

const express = require("express");
const path = require("path");
const {
  ENDPOINT,
  configStatus,
  searchProducts,
  getProduct,
  generateAffiliateLink
} = require("./shopee");

const app = express();
const PORT = Number(process.env.PORT || 3000);

app.use(express.json({ limit: "1mb" }));
app.use(express.static(path.join(__dirname, "..", "frontend")));

function fail(res, status, err) {
  return res.status(status).json({
    ok: false,
    kind: err.kind || "API",
    code: err.code || null,
    message: err.message || "Não foi possível concluir a operação."
  });
}

function requireApi(res) {
  const s = configStatus();
  if (!s.configured) {
    const err = new Error("A Shopee Open API não está configurada. Preencha SHOPEE_APP_ID e SHOPEE_SECRET no arquivo .env e reinicie o sistema.");
    err.kind = "CONFIG";
    fail(res, 503, err);
    return false;
  }
  return true;
}

app.get("/api/status", (req, res) => {
  const s = configStatus();
  res.json({
    ok: true,
    mode: s.configured ? "api" : "not_configured",
    configured: s.configured,
    hasAppId: s.hasAppId,
    hasSecret: s.hasSecret,
    endpoint: ENDPOINT
  });
});

app.get("/api/test", async (req, res) => {
  if (!requireApi(res)) return;
  try {
    const result = await searchProducts({ keyword: "fone", sortType: 1, page: 1, limit: 1 });
    res.json({ ok: true, message: `Conexão com a Shopee OK. ${result.items.length} oferta(s) recebida(s).` });
  } catch (err) {
    fail(res, err.kind === "CONFIG" ? 503 : 502, err);
  }
});

app.get("/api/products", async (req, res) => {
  if (!requireApi(res)) return;

  const keyword = String(req.query.q || "").slice(0, 120);
  const sortType = Number(req.query.sort || 1);
  const page = Math.max(1, Number(req.query.page || 1));
  const limit = Math.min(50, Math.max(1, Number(req.query.limit || 24)));

  try {
    const result = await searchProducts({ keyword, sortType, page, limit });
    res.json({ ok: true, mode: "api", ...result });
  } catch (err) {
    fail(res, err.kind === "CONFIG" ? 503 : 502, err);
  }
});

app.get("/api/products/:shopId/:itemId", async (req, res) => {
  if (!requireApi(res)) return;
  try {
    const item = await getProduct(req.params.shopId, req.params.itemId);
    if (!item) return res.status(404).json({ ok: false, kind: "NOT_FOUND", message: "A Shopee não retornou esse produto como oferta disponível para sua conta." });
    res.json({ ok: true, mode: "api", item });
  } catch (err) {
    fail(res, 502, err);
  }
});

app.post("/api/affiliate-link", async (req, res) => {
  if (!requireApi(res)) return;
  try {
    const link = await generateAffiliateLink(req.body?.originUrl, Array.isArray(req.body?.subIds) ? req.body.subIds : []);
    res.json({ ok: true, link });
  } catch (err) {
    fail(res, err.kind === "VALIDATION" ? 400 : 502, err);
  }
});

app.get("*", (req, res) => {
  res.sendFile(path.join(__dirname, "..", "frontend", "index.html"));
});

app.listen(PORT, "0.0.0.0", () => {
  console.log(`Shopee Oportunidades: http://localhost:${PORT}`);
  console.log(`Acesso pela rede: http://SEU-IP-DO-PC:${PORT}`);
});